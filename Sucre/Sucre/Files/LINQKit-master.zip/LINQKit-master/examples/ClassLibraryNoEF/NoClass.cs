﻿using GenericClassLibrary;

namespace ClassLibraryNoEF
{
    public class NoClass
    {
        public void X()
        {
            new GenericClass().X();
        }
    }
}
