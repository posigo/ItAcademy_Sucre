﻿namespace ClassLibraryNoEF
{
    class Program
    {
        static void Main(string[] args)
        {
            new NoClass().X();
        }
    }
}
