﻿using System;

namespace ClassLibraryStandard20
{
    public class Class1
    {
    }
}
