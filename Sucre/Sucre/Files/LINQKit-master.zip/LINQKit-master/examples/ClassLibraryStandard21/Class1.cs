﻿namespace ClassLibraryStandard21
{
    public class Class1
    {
    }
}
