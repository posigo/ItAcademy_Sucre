﻿using GenericClassLibrary;

namespace ClassLibraryWithEF
{
    public class EFClass
    {
        public void X()
        {
            new GenericClass().X();
        }
    }
}