﻿namespace ConsoleAppNetCore3Ef3.EntityFrameworkCore.Entities
{
    public enum RoomStatus
    {
        Unavailable = 0,
        Available = 1,
    }
}