﻿namespace LinqKit
{
    internal class ExpandableQueryTranslationPreprocessorOptions
    {
    }
}